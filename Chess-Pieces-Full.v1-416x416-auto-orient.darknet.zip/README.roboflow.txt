
Chess-Pieces-Full - v1 416x416-auto-orient
==============================

This dataset was exported via roboflow.ai on March 23, 2020 at 5:28 AM GMT

It includes 289 images.
Pieces are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


